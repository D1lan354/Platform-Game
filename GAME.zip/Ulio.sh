#!/bin/sh
echo -ne '\033c\033]0;Projekt 2d\a'
base_path="$(dirname "$(realpath "$0")")"
"$base_path/Ulio" "$@"
